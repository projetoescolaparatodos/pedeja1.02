# Assets / Imagens

## Logo
Adicione o arquivo `logo-pede-ja.png` nesta pasta.

O logo deve ter:
- Formato: PNG com transparência
- Tamanho recomendado: 400x400px
- Background: Transparente
- Cores: Verde (#045146) e Dourado (#E39110)

## Outras Imagens
Coloque aqui outras imagens estáticas do app.
